from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    ENV: str = "local"  # local | aws
    SECRET_KEY: str = "dev-secret-change"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 8
    
    # Database settings - will read from environment variables
    MYSQL_HOST: str = os.getenv("DB_HOST", "Wouter_Laptop")
    MYSQL_PORT: int = int(os.getenv("DB_PORT", "3306"))
    MYSQL_USER: str = os.getenv("DB_USER", "appuser")
    MYSQL_PASSWORD: str = os.getenv("DB_PASSWORD", "apppass")
    MYSQL_DB: str = os.getenv("DB_NAME", "eventdb")
    
    # Storage settings
    STORAGE_BACKEND: str = "local"  # local | s3
    STORAGE_LOCAL_DIR: str = "/data/uploads"
    S3_BUCKET: str | None = None
    S3_PREFIX: str = "uploads/"
    AWS_REGION: str = "af-south-1"

    class Config:
        env_file = ".env"

settings = Settings()